"""Unit tests for DS parsing and ID generation. These run with no network / no API keys.

Run:  pytest -q
"""
from __future__ import annotations

from io import BytesIO

from docx import Document

from app.integrations import ds_document


def _make_doc() -> bytes:
    doc = Document()
    for ds_id, title, body in [
        ("CONFIGF-0001", "Intake form", "Body one."),
        ("CONFIGF-0007", "Severity tiers", "Body two."),
        ("DATAFIELD-0003", "Product id", "Body three."),
    ]:
        p = doc.add_paragraph()
        p.add_run(f"{ds_id} — {title}").bold = True
        doc.add_paragraph(body)
    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def test_parse_finds_all_entries():
    parsed = ds_document.parse_docx_bytes(_make_doc())
    ids = {e.ds_id for e in parsed.entries}
    assert ids == {"CONFIGF-0001", "CONFIGF-0007", "DATAFIELD-0003"}


def test_families():
    parsed = ds_document.parse_docx_bytes(_make_doc())
    assert parsed.families() == {"CONFIGF", "DATAFIELD"}


def test_next_id_increments_highest_in_family():
    parsed = ds_document.parse_docx_bytes(_make_doc())
    assert parsed.next_id_for_family("CONFIGF") == "CONFIGF-0008"
    assert parsed.next_id_for_family("DATAFIELD") == "DATAFIELD-0004"


def test_insert_entry_roundtrips():
    parsed = ds_document.parse_docx_bytes(_make_doc())
    new_bytes = ds_document.insert_entry(
        parsed, "CONFIGF-0008", "CONFIGF", "New rule", "A newly drafted body."
    )
    reparsed = ds_document.parse_docx_bytes(new_bytes)
    ids = {e.ds_id for e in reparsed.entries}
    assert "CONFIGF-0008" in ids
    assert len(reparsed.entries) == 4
