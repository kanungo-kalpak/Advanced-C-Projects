"""Generate a small sample DS .docx you can upload to Google Drive for testing.

Run:  python -m scripts.make_sample_ds
Creates data/sample_ds.docx with a few entries across families. Upload it to Drive, share it
with your service account, and put its file id in DS_DOCX_FILE_ID.
"""
from __future__ import annotations

from pathlib import Path

from docx import Document

_ENTRIES = [
    ("CONFIGF-0001", "Complaint intake form configuration",
     "The system shall present a complaint intake form capturing reporter, product, and event "
     "date. All fields except comments are mandatory before submission."),
    ("CONFIGF-0002", "Complaint severity classification",
     "The system shall allow classification of a complaint into severity tiers. The selected "
     "tier shall drive downstream routing rules."),
    ("DATAFIELD-0001", "Product identifier field",
     "The product identifier field shall accept the catalogue code and validate it against the "
     "active product master. Invalid codes are rejected with a user-facing message."),
    ("GC-0001", "Audit trail on record change",
     "Every change to a controlled record shall be captured in an immutable audit trail "
     "recording actor, timestamp, previous value, and new value."),
]


def main() -> None:
    doc = Document()
    doc.add_heading("Design Specification (Sample)", level=0)
    for ds_id, title, body in _ENTRIES:
        p = doc.add_paragraph()
        run = p.add_run(f"{ds_id} — {title}")
        run.bold = True
        doc.add_paragraph(body)

    out = Path("data/sample_ds.docx")
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main()
