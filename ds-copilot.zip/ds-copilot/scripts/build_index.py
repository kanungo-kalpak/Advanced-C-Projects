"""Rebuild the embedding index from the current DS document on Drive.

Run:  python -m scripts.build_index
Useful after editing the DS document outside the agent, or to warm the index before a demo.
"""
from __future__ import annotations

from app.integrations import drive_client, ds_document, vectorstore


def main() -> None:
    raw = drive_client.download_ds_docx()
    parsed = ds_document.parse_docx_bytes(raw)
    count = vectorstore.rebuild_index(parsed)
    print(f"Indexed {count} entries. Families: {sorted(parsed.families())}")


if __name__ == "__main__":
    main()
