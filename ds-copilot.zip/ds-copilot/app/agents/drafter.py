"""Drafter agent: when no DS entry matches, draft a new one with Gemini.

The draft is grounded in real neighboring entries from the same family so the style, tone, and
level of detail match the existing document rather than being invented from scratch. The family
is inferred from the nearest candidate; if there are no candidates at all we fall back to a
generic family that you can rename.
"""
from __future__ import annotations

from app.integrations import ds_document, llm
from app.integrations.ds_document import ParsedDS
from app.state import Candidate, DraftEntry, UserStory

_SYSTEM = (
    "You are a meticulous quality systems author writing Design Specification (DS) entries for "
    "a GxP-regulated healthcare quality management system. You write precise, testable, "
    "implementation-neutral specifications. You never invent regulatory claims."
)

_PROMPT = """A new user story needs a Design Specification entry because no existing DS entry covers it.

USER STORY
Title: {title}
Description: {description}
Acceptance criteria:
{acceptance}

Below are existing DS entries from the same family ("{family}"). Match their structure, tone,
heading style, and level of detail exactly. Do NOT copy their content — write a new entry for
the user story above.

EXISTING ENTRIES IN FAMILY {family}
{examples}

Write ONLY the body of the new DS entry (no heading, no DS ID — those are added separately).
Keep it self-contained, testable, and traceable to the acceptance criteria."""


def _pick_family(candidates: list[Candidate], parsed: ParsedDS) -> str:
    if candidates:
        return candidates[0].family
    families = sorted(parsed.families())
    return families[0] if families else "DATAFIELD"


def draft_entry(
    story: UserStory, candidates: list[Candidate], parsed: ParsedDS
) -> DraftEntry:
    family = _pick_family(candidates, parsed)
    examples = "\n\n".join(
        f"{e.heading}\n{e.body}" for e in parsed.entries_in_family(family)[:3]
    ) or "(no existing examples in this family)"

    body = llm.generate(
        _PROMPT.format(
            title=story.title,
            description=story.description,
            acceptance=story.acceptance_criteria,
            family=family,
            examples=examples,
        ),
        system=_SYSTEM,
    )

    ds_id = parsed.next_id_for_family(family)
    heading = story.title.strip()
    return DraftEntry(ds_id=ds_id, family=family, heading=heading, body=body.strip())
