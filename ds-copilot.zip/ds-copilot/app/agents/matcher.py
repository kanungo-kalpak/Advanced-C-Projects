"""Matcher agent: turn a story into ranked candidate DS IDs.

This is pure retrieval — embed the story, pull nearest DS entries, and decide whether the top
hit clears the confidence threshold. No LLM call needed here; the semantic index does the work.
"""
from __future__ import annotations

from app.config import get_settings
from app.integrations import vectorstore
from app.state import Candidate, UserStory


def find_candidates(story: UserStory) -> tuple[list[Candidate], bool]:
    """Return (ranked candidates, has_confident_match)."""
    settings = get_settings()
    candidates = vectorstore.search(story.as_query(), top_k=settings.top_k_candidates)
    has_confident_match = bool(candidates) and candidates[0].score >= settings.match_threshold
    return candidates, has_confident_match
