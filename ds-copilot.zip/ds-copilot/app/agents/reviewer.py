"""Reviewer agent: a second Gemini pass that checks the draft before any human sees it.

This is the self-correction loop. The reviewer judges the draft against a rubric and either
passes it or returns a corrected version. The graph will loop drafter->reviewer a bounded number
of times so a bad draft is quietly fixed rather than shown to the approver.

The reviewer replies in a tiny JSON contract so the graph can branch on the result.
"""
from __future__ import annotations

import json

from app.integrations import llm
from app.state import DraftEntry, UserStory

_SYSTEM = (
    "You are a senior reviewer of Design Specification entries in a GxP quality system. "
    "You enforce house style and traceability. You are strict but constructive."
)

_PROMPT = """Review the drafted DS entry against this rubric:
1. Every acceptance criterion is traceable to something in the entry.
2. The entry is implementation-neutral (describes WHAT, not vendor-specific HOW).
3. It is testable (a validator could write a test case from it).
4. Tone and structure match a formal DS entry (no marketing language, no hedging).
5. No invented regulatory or compliance claims.

USER STORY
Title: {title}
Acceptance criteria:
{acceptance}

DRAFTED ENTRY (family {family}, proposed id {ds_id})
{body}

Respond with ONLY a JSON object, no markdown fences, in exactly this shape:
{{"passed": true|false, "notes": "<one or two sentences>", "revised_body": "<the corrected body if passed is false, otherwise an empty string>"}}"""


def _parse_json(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start != -1 and end != -1:
        cleaned = cleaned[start : end + 1]
    return json.loads(cleaned)


def review(story: UserStory, draft: DraftEntry) -> tuple[bool, str, DraftEntry]:
    """Return (passed, notes, possibly_revised_draft)."""
    raw = llm.generate(
        _PROMPT.format(
            title=story.title,
            acceptance=story.acceptance_criteria,
            family=draft.family,
            ds_id=draft.ds_id,
            body=draft.body,
        ),
        system=_SYSTEM,
        temperature=0.0,
    )

    try:
        parsed = _parse_json(raw)
    except (json.JSONDecodeError, ValueError):
        # If the model didn't return clean JSON, fail safe: treat as passed with a note so we
        # don't loop forever on a formatting quirk.
        return True, "Reviewer response was not valid JSON; passing draft unchanged.", draft

    passed = bool(parsed.get("passed", True))
    notes = str(parsed.get("notes", "")).strip()
    revised = str(parsed.get("revised_body", "")).strip()

    if not passed and revised:
        draft = DraftEntry(
            ds_id=draft.ds_id, family=draft.family, heading=draft.heading, body=revised
        )
    return passed, notes, draft
