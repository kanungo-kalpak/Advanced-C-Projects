"""FastAPI entrypoint.

- Exposes `/slack/events` which Slack calls for slash commands and interactivity.
- On startup, downloads the DS document from Drive and builds the embedding index so the very
  first `/link-ds` can match immediately.
- Exposes `/health` for uptime checks.
"""
from __future__ import annotations

import logging

import uvicorn
from fastapi import FastAPI, Request
from slack_bolt.adapter.fastapi import SlackRequestHandler

from app.config import get_settings
from app.integrations import drive_client, ds_document, vectorstore
from app.slack.handlers import app as slack_app

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ds-copilot")

api = FastAPI(title="DS Traceability Steward")
handler = SlackRequestHandler(slack_app)


@api.on_event("startup")
def build_index_on_startup() -> None:
    logger.info("Downloading DS document from Google Drive…")
    raw = drive_client.download_ds_docx()
    parsed = ds_document.parse_docx_bytes(raw)
    count = vectorstore.rebuild_index(parsed)
    logger.info("Indexed %d DS entries across families: %s", count, sorted(parsed.families()))


@api.post("/slack/events")
async def slack_events(req: Request):
    return await handler.handle(req)


@api.get("/health")
def health() -> dict:
    return {"status": "ok"}


def main() -> None:
    settings = get_settings()
    uvicorn.run("app.main:api", host=settings.host, port=settings.port, reload=False)


if __name__ == "__main__":
    main()
