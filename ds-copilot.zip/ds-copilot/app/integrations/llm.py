"""Thin wrapper around the Google Gemini API (google-genai SDK).

Isolating the LLM behind one function means swapping models (or providers) later touches
exactly one file.
"""
from __future__ import annotations

from google import genai
from google.genai import types

from app.config import get_settings

_client: genai.Client | None = None


def _get_client() -> genai.Client:
    global _client
    if _client is None:
        settings = get_settings()
        _client = genai.Client(api_key=settings.gemini_api_key)
    return _client


def generate(prompt: str, *, system: str | None = None, temperature: float = 0.2) -> str:
    """Send a single prompt to Gemini and return the text response.

    `temperature` is kept low by default because DS drafting should be consistent and
    conservative, not creative.
    """
    settings = get_settings()
    client = _get_client()

    config = types.GenerateContentConfig(
        temperature=temperature,
        system_instruction=system,
    )
    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config=config,
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text
