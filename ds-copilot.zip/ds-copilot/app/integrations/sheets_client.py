"""Google Sheets tracker for User Story <-> DS ID mappings.

Uses the Sheets `append` API rather than rewriting a whole file, so concurrent approvals never
clobber each other's rows. The tab is created with a header row on first use.
"""
from __future__ import annotations

from datetime import datetime, timezone

from google.oauth2 import service_account
from googleapiclient.discovery import build

from app.config import get_settings

_SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
_HEADER = ["Timestamp (UTC)", "Story ID", "Story Title", "DS ID(s)", "Action", "Approver"]

_service = None


def _get_service():
    global _service
    if _service is None:
        settings = get_settings()
        creds = service_account.Credentials.from_service_account_file(
            settings.google_service_account_file, scopes=_SCOPES
        )
        _service = build("sheets", "v4", credentials=creds, cache_discovery=False)
    return _service


def _ensure_header() -> None:
    settings = get_settings()
    service = _get_service()
    rng = f"{settings.tracker_sheet_tab}!A1:F1"
    resp = (
        service.spreadsheets()
        .values()
        .get(spreadsheetId=settings.tracker_sheet_id, range=rng)
        .execute()
    )
    if not resp.get("values"):
        service.spreadsheets().values().update(
            spreadsheetId=settings.tracker_sheet_id,
            range=rng,
            valueInputOption="RAW",
            body={"values": [_HEADER]},
        ).execute()


def append_mapping(
    story_id: str,
    story_title: str,
    ds_ids: list[str],
    action: str,
    approver: str,
) -> None:
    """Append one row logging a confirmed story <-> DS ID mapping."""
    settings = get_settings()
    service = _get_service()
    _ensure_header()

    row = [
        datetime.now(timezone.utc).isoformat(timespec="seconds"),
        story_id,
        story_title,
        ", ".join(ds_ids),
        action,
        approver,
    ]
    service.spreadsheets().values().append(
        spreadsheetId=settings.tracker_sheet_id,
        range=f"{settings.tracker_sheet_tab}!A:F",
        valueInputOption="RAW",
        insertDataOption="INSERT_ROWS",
        body={"values": [row]},
    ).execute()
