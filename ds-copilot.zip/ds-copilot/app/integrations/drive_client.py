"""Google Drive access for the DS document.

We always fetch the *current* revision right before editing (never a cached copy), then upload
the edited bytes as a new revision. Drive keeps the revision history automatically, which
becomes the audit trail of who-approved-what-when.
"""
from __future__ import annotations

from io import BytesIO

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload, MediaIoBaseUpload

from app.config import get_settings

_SCOPES = ["https://www.googleapis.com/auth/drive"]
_DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

_service = None


def _get_service():
    global _service
    if _service is None:
        settings = get_settings()
        creds = service_account.Credentials.from_service_account_file(
            settings.google_service_account_file, scopes=_SCOPES
        )
        _service = build("drive", "v3", credentials=creds, cache_discovery=False)
    return _service


def download_ds_docx() -> bytes:
    """Download the latest revision of the DS .docx as raw bytes."""
    settings = get_settings()
    service = _get_service()
    request = service.files().get_media(fileId=settings.ds_docx_file_id)

    buffer = BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk()
    return buffer.getvalue()


def upload_ds_docx(raw: bytes) -> str:
    """Upload edited bytes as a new revision of the same file. Returns the file id."""
    settings = get_settings()
    service = _get_service()
    media = MediaIoBaseUpload(BytesIO(raw), mimetype=_DOCX_MIME, resumable=True)
    updated = (
        service.files()
        .update(fileId=settings.ds_docx_file_id, media_body=media, fields="id")
        .execute()
    )
    return updated["id"]
