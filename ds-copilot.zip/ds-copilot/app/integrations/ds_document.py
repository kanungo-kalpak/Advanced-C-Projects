"""Parse a DS Word document into structured entries and insert new entries.

Assumptions about the DS `.docx` structure (tweak the regex in `DS_ID_PATTERN` to match your
real house format):

- Each DS entry starts with a heading paragraph whose text begins with a DS ID token such as
  `CONFIGF-0123`, `DATAFIELD-0456`, `GC-0007`, etc.
- The family is the alphabetic prefix before the dash; the number is the numeric suffix.
- Body paragraphs follow the heading until the next DS-ID heading.

Only the parsing contract lives here; matching/embedding lives in `vectorstore.py`.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from io import BytesIO

from docx import Document
from docx.document import Document as DocxDocument

# e.g. "CONFIGF-0123", "DATAFIELD-0456", "IS-WS-0012" (family may contain a hyphen)
DS_ID_PATTERN = re.compile(r"^(?P<ds_id>(?P<family>[A-Z][A-Z\-]*[A-Z])-(?P<num>\d{3,6}))\b(?P<rest>.*)$")


@dataclass
class DSEntry:
    ds_id: str
    family: str
    number: int
    heading: str            # full heading text (id + title)
    body: str               # concatenated body paragraphs
    start_para_index: int   # index of the heading paragraph in the docx
    end_para_index: int     # exclusive; index of the next heading (or len)

    def searchable_text(self) -> str:
        return f"{self.heading}\n{self.body}".strip()


@dataclass
class ParsedDS:
    document: DocxDocument
    entries: list[DSEntry] = field(default_factory=list)

    def families(self) -> set[str]:
        return {e.family for e in self.entries}

    def entries_in_family(self, family: str) -> list[DSEntry]:
        return [e for e in self.entries if e.family == family]

    def next_id_for_family(self, family: str) -> str:
        """Compute the next sequential DS ID for a family (highest number + 1)."""
        members = self.entries_in_family(family)
        width = 4
        highest = 0
        for e in members:
            highest = max(highest, e.number)
            # preserve the zero-padding width actually used in the doc
            suffix = e.ds_id.rsplit("-", 1)[-1]
            width = max(width, len(suffix))
        return f"{family}-{highest + 1:0{width}d}"


def parse_docx_bytes(raw: bytes) -> ParsedDS:
    """Parse DS entries from the bytes of a .docx file."""
    document = Document(BytesIO(raw))
    return _parse(document)


def parse_docx_path(path: str) -> ParsedDS:
    document = Document(path)
    return _parse(document)


def _parse(document: DocxDocument) -> ParsedDS:
    paragraphs = document.paragraphs
    headings: list[tuple[int, re.Match[str]]] = []
    for idx, para in enumerate(paragraphs):
        text = para.text.strip()
        if not text:
            continue
        m = DS_ID_PATTERN.match(text)
        if m:
            headings.append((idx, m))

    entries: list[DSEntry] = []
    for i, (para_idx, m) in enumerate(headings):
        end = headings[i + 1][0] if i + 1 < len(headings) else len(paragraphs)
        body_paras = [paragraphs[j].text for j in range(para_idx + 1, end)]
        body = "\n".join(p for p in body_paras if p.strip())
        entries.append(
            DSEntry(
                ds_id=m.group("ds_id"),
                family=m.group("family"),
                number=int(m.group("num")),
                heading=paragraphs[para_idx].text.strip(),
                body=body,
                start_para_index=para_idx,
                end_para_index=end,
            )
        )

    return ParsedDS(document=document, entries=entries)


def insert_entry(parsed: ParsedDS, ds_id: str, family: str, heading: str, body: str) -> bytes:
    """Insert a new DS entry into the correct family section and return updated .docx bytes.

    Placement rule: insert immediately after the *last* existing entry of the same family so
    the new entry lands next to its relatives. If the family is brand new, append to the end
    of the document.
    """
    document = parsed.document
    members = parsed.entries_in_family(family)

    heading_text = heading if heading.startswith(ds_id) else f"{ds_id} — {heading}"

    if members:
        anchor = max(members, key=lambda e: e.number)
        # paragraph object just before which we insert (the paragraph at end index, if any)
        insert_before_idx = anchor.end_para_index
        paragraphs = document.paragraphs
        if insert_before_idx < len(paragraphs):
            ref_para = paragraphs[insert_before_idx]
            _insert_paragraph_before(ref_para, heading_text, bold=True)
            for line in body.split("\n"):
                _insert_paragraph_before(ref_para, line)
        else:
            _append(document, heading_text, body)
    else:
        _append(document, heading_text, body)

    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def _append(document: DocxDocument, heading_text: str, body: str) -> None:
    h = document.add_paragraph()
    run = h.add_run(heading_text)
    run.bold = True
    for line in body.split("\n"):
        document.add_paragraph(line)


def _insert_paragraph_before(ref_paragraph, text: str, bold: bool = False):
    """python-docx has no public 'insert before' for paragraphs; use the XML helper."""
    new_p = ref_paragraph.insert_paragraph_before()
    run = new_p.add_run(text)
    run.bold = bold
    return new_p
