"""Embedding index over DS entries using ChromaDB + sentence-transformers.

The index is the retrieval half of the matcher: embed every DS entry once, then embed an
incoming story and pull the nearest entries. Cosine similarity is derived from Chroma's
distance so we can apply a human-readable threshold.
"""
from __future__ import annotations

import chromadb
from chromadb.config import Settings as ChromaSettings
from sentence_transformers import SentenceTransformer

from app.config import get_settings
from app.integrations.ds_document import ParsedDS
from app.state import Candidate

_COLLECTION = "ds_entries"

_model: SentenceTransformer | None = None
_client: chromadb.ClientAPI | None = None


def _get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer(get_settings().embed_model)
    return _model


def _get_client() -> chromadb.ClientAPI:
    global _client
    if _client is None:
        settings = get_settings()
        _client = chromadb.PersistentClient(
            path=settings.chroma_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
    return _client


def _embed(texts: list[str]) -> list[list[float]]:
    model = _get_model()
    vectors = model.encode(texts, normalize_embeddings=True)
    return [v.tolist() for v in vectors]


def rebuild_index(parsed: ParsedDS) -> int:
    """Wipe and rebuild the collection from the parsed DS document. Returns entry count."""
    client = _get_client()
    try:
        client.delete_collection(_COLLECTION)
    except Exception:
        pass  # collection may not exist yet

    collection = client.create_collection(
        _COLLECTION, metadata={"hnsw:space": "cosine"}
    )

    if not parsed.entries:
        return 0

    ids = [e.ds_id for e in parsed.entries]
    documents = [e.searchable_text() for e in parsed.entries]
    metadatas = [{"family": e.family, "heading": e.heading} for e in parsed.entries]
    embeddings = _embed(documents)

    collection.add(ids=ids, documents=documents, metadatas=metadatas, embeddings=embeddings)
    return len(ids)


def add_entry(ds_id: str, family: str, heading: str, text: str) -> None:
    """Add a single newly approved DS entry so future stories can match against it."""
    collection = _get_client().get_collection(_COLLECTION)
    collection.add(
        ids=[ds_id],
        documents=[text],
        metadatas=[{"family": family, "heading": heading}],
        embeddings=_embed([text]),
    )


def search(query: str, top_k: int) -> list[Candidate]:
    """Return the top_k most similar DS entries as ranked candidates."""
    collection = _get_client().get_collection(_COLLECTION)
    result = collection.query(
        query_embeddings=_embed([query]),
        n_results=top_k,
        include=["documents", "metadatas", "distances"],
    )

    candidates: list[Candidate] = []
    ids = result.get("ids", [[]])[0]
    docs = result.get("documents", [[]])[0]
    metas = result.get("metadatas", [[]])[0]
    dists = result.get("distances", [[]])[0]

    for ds_id, doc, meta, dist in zip(ids, docs, metas, dists):
        # cosine distance -> cosine similarity
        score = max(0.0, 1.0 - float(dist))
        candidates.append(
            Candidate(
                ds_id=ds_id,
                family=str(meta.get("family", "")),
                heading=str(meta.get("heading", "")),
                text=doc,
                score=round(score, 4),
            )
        )
    return candidates
