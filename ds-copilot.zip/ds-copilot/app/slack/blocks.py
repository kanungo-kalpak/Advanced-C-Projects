"""Slack Block Kit builders: the input modal and the proposal message with buttons."""
from __future__ import annotations

from app.state import Candidate, DraftEntry

MODAL_CALLBACK = "link_ds_modal"


def story_modal() -> dict:
    """The modal that opens on /link-ds, collecting the story fields as structured input."""
    return {
        "type": "modal",
        "callback_id": MODAL_CALLBACK,
        "title": {"type": "plain_text", "text": "Link a story to DS"},
        "submit": {"type": "plain_text", "text": "Run agent"},
        "close": {"type": "plain_text", "text": "Cancel"},
        "blocks": [
            {
                "type": "input",
                "block_id": "story_id",
                "label": {"type": "plain_text", "text": "Story ID"},
                "element": {
                    "type": "plain_text_input",
                    "action_id": "value",
                    "placeholder": {"type": "plain_text", "text": "e.g. US-4278655"},
                },
            },
            {
                "type": "input",
                "block_id": "title",
                "label": {"type": "plain_text", "text": "Title"},
                "element": {"type": "plain_text_input", "action_id": "value"},
            },
            {
                "type": "input",
                "block_id": "description",
                "label": {"type": "plain_text", "text": "Description"},
                "element": {"type": "plain_text_input", "action_id": "value", "multiline": True},
            },
            {
                "type": "input",
                "block_id": "acceptance",
                "label": {"type": "plain_text", "text": "Acceptance criteria"},
                "element": {"type": "plain_text_input", "action_id": "value", "multiline": True},
            },
        ],
    }


def _truncate(text: str, limit: int = 2900) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


def proposal_message(
    story_id: str,
    thread_ts_placeholder: str,
    candidates: list[Candidate],
    draft: DraftEntry | None,
    has_match: bool,
) -> list[dict]:
    """Build the proposal blocks. `value` on each button carries the correlation key so the
    handler can resume the right graph run."""
    blocks: list[dict] = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"DS proposal for {story_id}"},
        }
    ]

    if candidates:
        lines = [
            f"*{c.ds_id}* — {c.heading}  _(similarity {c.score:.2f})_"
            for c in candidates
        ]
        blocks.append(
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "*Candidate matches:*\n" + "\n".join(lines)},
            }
        )

    if has_match and candidates:
        blocks.append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"Top candidate *{candidates[0].ds_id}* clears the confidence threshold. "
                    "Approve to link the story to it.",
                },
            }
        )
    elif draft is not None:
        blocks.append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*No confident match. Proposed new entry {draft.ds_id}:*\n"
                    f"```{_truncate(draft.body)}```",
                },
            }
        )

    blocks.append(
        {
            "type": "actions",
            "block_id": "decision",
            "elements": [
                {
                    "type": "button",
                    "style": "primary",
                    "text": {"type": "plain_text", "text": "Approve"},
                    "action_id": "ds_approve",
                    "value": story_id,
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Edit"},
                    "action_id": "ds_edit",
                    "value": story_id,
                },
                {
                    "type": "button",
                    "style": "danger",
                    "text": {"type": "plain_text", "text": "Reject"},
                    "action_id": "ds_reject",
                    "value": story_id,
                },
            ],
        }
    )
    return blocks


def edit_modal(thread_ts: str, current_body: str) -> dict:
    """Modal for editing a drafted body before approval. `private_metadata` carries the key."""
    return {
        "type": "modal",
        "callback_id": "ds_edit_modal",
        "private_metadata": thread_ts,
        "title": {"type": "plain_text", "text": "Edit DS entry"},
        "submit": {"type": "plain_text", "text": "Approve edited"},
        "close": {"type": "plain_text", "text": "Cancel"},
        "blocks": [
            {
                "type": "input",
                "block_id": "body",
                "label": {"type": "plain_text", "text": "DS entry body"},
                "element": {
                    "type": "plain_text_input",
                    "action_id": "value",
                    "multiline": True,
                    "initial_value": current_body[:2900],
                },
            }
        ],
    }
