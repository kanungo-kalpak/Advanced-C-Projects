"""Slack event handlers: /link-ds command, modal submission, and Approve/Edit/Reject buttons.

The correlation key between Slack and a paused graph run is the Slack **thread timestamp**
(`thread_ts`) of the proposal message. We store it as the LangGraph `thread_id`, so a button
click can resume exactly the run it belongs to.

A tiny in-memory map (`_draft_bodies`) lets the Edit modal prefill the current draft text; it is
convenience only — the source of truth for the run is the SQLite checkpoint.
"""
from __future__ import annotations

from slack_bolt import App

from app.config import get_settings
from app.graph import get_graph
from app.slack import blocks
from app.state import Candidate, DraftEntry, UserStory

settings = get_settings()
app = App(token=settings.slack_bot_token, signing_secret=settings.slack_signing_secret)

# thread_ts -> latest draft body (for prefilling the edit modal)
_draft_bodies: dict[str, str] = {}


def _config(thread_ts: str) -> dict:
    return {"configurable": {"thread_id": thread_ts}}


def _interrupt_payload(result: dict) -> dict | None:
    """Extract the payload from a LangGraph interrupt, across minor version shapes."""
    interrupts = result.get("__interrupt__")
    if not interrupts:
        return None
    first = interrupts[0]
    return getattr(first, "value", None) or (first.get("value") if isinstance(first, dict) else None)


@app.command("/link-ds")
def handle_command(ack, body, client):
    ack()
    client.views_open(trigger_id=body["trigger_id"], view=blocks.story_modal())


@app.view(blocks.MODAL_CALLBACK)
def handle_modal_submit(ack, body, view, client):
    ack()
    values = view["state"]["values"]

    def field(block_id: str) -> str:
        return values[block_id]["value"]["value"].strip()

    story = UserStory(
        story_id=field("story_id"),
        title=field("title"),
        description=field("description"),
        acceptance_criteria=field("acceptance"),
    )
    user_id = body["user"]["id"]

    # Post a placeholder so we get a message ts to use as the correlation key / thread_id.
    posted = client.chat_postMessage(
        channel=user_id,  # DM the invoking user; change to a channel id to post publicly
        text=f"Running the DS agent for {story.story_id}…",
    )
    channel = posted["channel"]
    thread_ts = posted["ts"]

    graph = get_graph()
    state = {
        "story": story.model_dump(),
        "slack_channel": channel,
        "slack_thread_ts": thread_ts,
    }
    result = graph.invoke(state, config=_config(thread_ts))

    payload = _interrupt_payload(result)
    if payload is None:
        # No interrupt means the graph finished without needing approval (shouldn't happen in
        # the normal flow, but handle gracefully).
        client.chat_update(
            channel=channel, ts=thread_ts,
            text=f"Done: {result.get('status', 'complete')}",
        )
        return

    candidates = [Candidate(**c) for c in payload.get("candidates", [])]
    draft_dict = payload.get("draft")
    draft = DraftEntry(**draft_dict) if draft_dict else None
    has_match = payload.get("kind") == "match"
    if draft:
        _draft_bodies[thread_ts] = draft.body

    client.chat_update(
        channel=channel,
        ts=thread_ts,
        text=f"DS proposal for {story.story_id}",
        blocks=blocks.proposal_message(story.story_id, thread_ts, candidates, draft, has_match),
    )


def _resume(thread_ts: str, decision: str, edited_body: str | None = None) -> dict:
    from langgraph.types import Command

    graph = get_graph()
    return graph.invoke(
        Command(resume={"decision": decision, "edited_body": edited_body}),
        config=_config(thread_ts),
    )


def _finish_text(result: dict) -> str:
    status = result.get("status", "done")
    ds_ids = ", ".join(result.get("final_ds_ids", []))
    mapping = {
        "linked-existing": f"Linked to existing {ds_ids}.",
        "created-new": f"New entry {ds_ids} written to the DS document and tracker.",
        "rejected": "Rejected. Nothing was written.",
    }
    return mapping.get(status, f"Status: {status}")


@app.action("ds_approve")
def handle_approve(ack, body, client):
    ack()
    channel = body["channel"]["id"]
    thread_ts = body["message"]["ts"]
    result = _resume(thread_ts, "approve")
    client.chat_update(channel=channel, ts=thread_ts, text=_finish_text(result), blocks=[])
    client.chat_postMessage(channel=channel, thread_ts=thread_ts, text=_finish_text(result))


@app.action("ds_reject")
def handle_reject(ack, body, client):
    ack()
    channel = body["channel"]["id"]
    thread_ts = body["message"]["ts"]
    result = _resume(thread_ts, "reject")
    client.chat_update(channel=channel, ts=thread_ts, text=_finish_text(result), blocks=[])


@app.action("ds_edit")
def handle_edit(ack, body, client):
    ack()
    thread_ts = body["message"]["ts"]
    current = _draft_bodies.get(thread_ts, "")
    client.views_open(
        trigger_id=body["trigger_id"], view=blocks.edit_modal(thread_ts, current)
    )


@app.view("ds_edit_modal")
def handle_edit_submit(ack, body, view, client):
    ack()
    thread_ts = view["private_metadata"]
    edited = view["state"]["values"]["body"]["value"]["value"]
    result = _resume(thread_ts, "approve", edited_body=edited)

    user_id = body["user"]["id"]
    client.chat_postMessage(channel=user_id, thread_ts=thread_ts, text=_finish_text(result))
