"""Typed data structures shared across the pipeline.

`GraphState` is the single dict that flows through every LangGraph node. Each node reads
the fields it needs and returns a partial dict that LangGraph merges back in.
"""
from __future__ import annotations

from typing import Any, Literal, Optional, TypedDict

from pydantic import BaseModel


class UserStory(BaseModel):
    """A normalized user story, regardless of where it came from (Slack today, Azure later)."""

    story_id: str
    title: str
    description: str
    acceptance_criteria: str

    def as_query(self) -> str:
        """Flatten the story into a single string for embedding / matching."""
        return f"{self.title}\n\n{self.description}\n\nAcceptance criteria:\n{self.acceptance_criteria}"


class Candidate(BaseModel):
    """One possible existing DS entry that might satisfy the story."""

    ds_id: str
    family: str
    heading: str
    text: str
    score: float  # cosine similarity, 0..1


class DraftEntry(BaseModel):
    """A newly drafted DS entry awaiting human approval."""

    ds_id: str
    family: str
    heading: str
    body: str

    def rendered(self) -> str:
        return f"{self.ds_id} — {self.heading}\n\n{self.body}"


# The decision the human returns from the Slack buttons.
Decision = Literal["approve", "reject", "edit"]


class GraphState(TypedDict, total=False):
    """State object passed between graph nodes."""

    # Inputs
    story: dict            # serialized UserStory
    slack_channel: str
    slack_thread_ts: str   # doubles as the LangGraph thread_id / correlation key

    # Produced along the way
    candidates: list[dict]        # serialized list[Candidate]
    has_confident_match: bool
    draft: Optional[dict]         # serialized DraftEntry
    review_notes: str
    review_passed: bool
    review_attempts: int

    # Human decision (arrives on resume)
    decision: Optional[Decision]
    edited_body: Optional[str]    # populated when the human chose "edit"

    # Outputs
    final_ds_ids: list[str]
    status: str                   # human-readable outcome
    error: Optional[str]
