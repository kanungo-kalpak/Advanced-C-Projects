r"""The agentic pipeline, built with LangGraph.

Flow:

    ingest -> retrieve -> (confident match?) --yes--> present -> [HUMAN GATE] -> finalize
                                            \--no---> draft -> review --(fail & attempts left)--> draft
                                                                     \--pass--> present -> [HUMAN GATE] -> finalize

`present` calls `interrupt()`, which suspends the run and checkpoints its state to SQLite. The
Slack layer posts the proposal, and when the human clicks a button we resume with
`Command(resume={...})`. `finalize` performs the Drive + Sheets write-back on approval.
"""
from __future__ import annotations

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from app.agents import drafter, matcher, reviewer
from app.config import get_settings
from app.integrations import ds_document, drive_client, sheets_client, vectorstore
from app.state import Candidate, DraftEntry, GraphState, UserStory

_MAX_REVIEW_ATTEMPTS = 2


# --------------------------------------------------------------------------- nodes


def ingest_node(state: GraphState) -> GraphState:
    story = UserStory(**state["story"])
    return {"review_attempts": 0, "status": "ingested", "story": story.model_dump()}


def retrieve_node(state: GraphState) -> GraphState:
    story = UserStory(**state["story"])
    candidates, confident = matcher.find_candidates(story)
    return {
        "candidates": [c.model_dump() for c in candidates],
        "has_confident_match": confident,
    }


def draft_node(state: GraphState) -> GraphState:
    story = UserStory(**state["story"])
    candidates = [Candidate(**c) for c in state.get("candidates", [])]
    parsed = _load_parsed_ds()
    draft = drafter.draft_entry(story, candidates, parsed)
    return {
        "draft": draft.model_dump(),
        "review_attempts": state.get("review_attempts", 0) + 1,
    }


def review_node(state: GraphState) -> GraphState:
    story = UserStory(**state["story"])
    draft = DraftEntry(**state["draft"])
    passed, notes, revised = reviewer.review(story, draft)
    return {
        "review_passed": passed,
        "review_notes": notes,
        "draft": revised.model_dump(),
    }


def present_node(state: GraphState) -> GraphState:
    """Suspend the run and wait for a human decision from Slack.

    `interrupt(payload)` returns the value passed to `Command(resume=...)` when the run is
    resumed. We hand back the decision + any edited body.
    """
    resume_value = interrupt(
        {
            "kind": "match" if state.get("has_confident_match") else "draft",
            "candidates": state.get("candidates", []),
            "draft": state.get("draft"),
        }
    )
    decision = (resume_value or {}).get("decision")
    edited_body = (resume_value or {}).get("edited_body")
    return {"decision": decision, "edited_body": edited_body}


def finalize_node(state: GraphState) -> GraphState:
    story = UserStory(**state["story"])
    decision = state.get("decision")
    approver = (state.get("story") or {}).get("story_id", "unknown")

    if decision == "reject":
        return {"status": "rejected", "final_ds_ids": []}

    # Approve of an existing match -> just log the mapping, no doc edit.
    if state.get("has_confident_match"):
        candidates = [Candidate(**c) for c in state.get("candidates", [])]
        ds_ids = [candidates[0].ds_id] if candidates else []
        sheets_client.append_mapping(
            story.story_id, story.title, ds_ids, "matched-existing", approver
        )
        return {"status": "linked-existing", "final_ds_ids": ds_ids}

    # Otherwise we're approving a drafted entry (possibly edited by the human).
    draft = DraftEntry(**state["draft"])
    if state.get("edited_body"):
        draft = DraftEntry(
            ds_id=draft.ds_id,
            family=draft.family,
            heading=draft.heading,
            body=state["edited_body"],
        )

    # Re-fetch the CURRENT revision right before editing (never a stale copy).
    parsed = _load_parsed_ds()
    updated_bytes = ds_document.insert_entry(
        parsed, draft.ds_id, draft.family, draft.heading, draft.body
    )
    drive_client.upload_ds_docx(updated_bytes)

    # Keep the search index consistent so the next story can match this new entry.
    vectorstore.add_entry(
        draft.ds_id, draft.family, draft.heading, draft.rendered()
    )

    sheets_client.append_mapping(
        story.story_id, story.title, [draft.ds_id], "drafted-new", approver
    )
    return {"status": "created-new", "final_ds_ids": [draft.ds_id]}


# --------------------------------------------------------------------------- edges


def _after_retrieve(state: GraphState) -> str:
    return "present" if state.get("has_confident_match") else "draft"


def _after_review(state: GraphState) -> str:
    if state.get("review_passed"):
        return "present"
    if state.get("review_attempts", 0) >= _MAX_REVIEW_ATTEMPTS:
        # Give up looping; present the best draft we have.
        return "present"
    return "draft"


# --------------------------------------------------------------------------- helpers


def _load_parsed_ds():
    """Download and parse the current DS docx from Drive."""
    raw = drive_client.download_ds_docx()
    return ds_document.parse_docx_bytes(raw)


_compiled = None
_saver_cm = None


def get_graph():
    """Compile the graph once, backed by a SQLite checkpointer for durable pause/resume."""
    global _compiled, _saver_cm
    if _compiled is None:
        settings = get_settings()
        _saver_cm = SqliteSaver.from_conn_string(settings.checkpoint_db)
        saver = _saver_cm.__enter__()

        builder = StateGraph(GraphState)
        builder.add_node("ingest", ingest_node)
        builder.add_node("retrieve", retrieve_node)
        builder.add_node("draft", draft_node)
        builder.add_node("review", review_node)
        builder.add_node("present", present_node)
        builder.add_node("finalize", finalize_node)

        builder.add_edge(START, "ingest")
        builder.add_edge("ingest", "retrieve")
        builder.add_conditional_edges("retrieve", _after_retrieve, {"present": "present", "draft": "draft"})
        builder.add_edge("draft", "review")
        builder.add_conditional_edges("review", _after_review, {"present": "present", "draft": "draft"})
        builder.add_edge("present", "finalize")
        builder.add_edge("finalize", END)

        _compiled = builder.compile(checkpointer=saver)
    return _compiled
