"""Central configuration, loaded once from the environment / .env file."""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # LLM
    gemini_api_key: str
    gemini_model: str = "gemini-2.0-flash"

    # Slack
    slack_bot_token: str
    slack_signing_secret: str

    # Google Workspace
    google_service_account_file: str = "data/service_account.json"
    ds_docx_file_id: str
    tracker_sheet_id: str
    tracker_sheet_tab: str = "Sheet1"

    # Behaviour
    match_threshold: float = 0.75
    top_k_candidates: int = 3
    embed_model: str = "all-MiniLM-L6-v2"

    # Local paths
    chroma_dir: str = "data/chroma"
    checkpoint_db: str = "data/checkpoints.sqlite"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance (read the environment only once)."""
    return Settings()  # type: ignore[call-arg]
