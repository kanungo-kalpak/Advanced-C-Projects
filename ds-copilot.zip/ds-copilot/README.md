# DS Traceability Steward — Agentic Slack Copilot

An agentic AI system that links Slack user stories to Design Specification (DS) IDs.
When a user story is posted, the agent:

1. **Reads** the story + acceptance criteria from a Slack modal.
2. **Matches** it against the existing DS document (semantic search over embeddings) and
   returns the top **ranked candidate DS IDs**.
3. If nothing matches confidently, a **drafting agent** (Google Gemini) writes a new DS entry
   in the style of its DS family.
4. A **reviewer agent** double-checks the draft's format/style before a human ever sees it
   (AI reviewing AI — a self-correction loop).
5. The proposal is posted back to Slack with **Approve / Edit / Reject** buttons.
   The LangGraph run **pauses** here and its state is checkpointed to SQLite.
6. On **Approve**, the agent appends the entry to the DS `.docx` on **Google Drive**
   (uploading a new revision — Drive's revision history is your audit trail), logs the
   `User Story ↔ DS ID` pair to a **Google Sheet**, re-embeds the new entry, and replies in
   the Slack thread confirming the DS ID.

```
Slack (/link-ds modal + buttons)
        │  webhook
        ▼
FastAPI  ──►  LangGraph pipeline
                 ingest → retrieve → draft → review → [HUMAN GATE] → write-back → confirm
                 │            │         │        │                        │
                 │        ChromaDB   Gemini   Gemini                 Drive + Sheets
                 │      (embeddings)
                 ▼
             SQLite checkpoint (remembers where the run paused)
```

---

## 1. Prerequisites

- Python 3.11+
- A **Slack workspace** where you can create an app (the free plan is fine)
- A **Google Cloud project** with the Drive API and Sheets API enabled
- A **Google Gemini API key** (https://aistudio.google.com/apikey)
- **ngrok** (free) — gives your laptop a public URL so Slack can reach it: https://ngrok.com/download

---

## 2. Install

```bash
cd ds-copilot
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
```

---

## 3. Google Cloud setup (Drive + Sheets)

1. Go to https://console.cloud.google.com → create a project.
2. **APIs & Services → Library** → enable **Google Drive API** and **Google Sheets API**.
3. **APIs & Services → Credentials → Create Credentials → Service account**.
   Give it a name, create it, then open it → **Keys → Add key → JSON**. Download the file.
4. Save that JSON as `data/service_account.json` in this project.
5. Open the JSON and copy the `client_email` value (looks like
   `something@your-project.iam.gserviceaccount.com`).
6. **Share your DS document** (the `.docx` in Google Drive) with that `client_email`,
   giving it **Editor** access. Copy the file's ID from its URL
   (`https://drive.google.com/file/d/<THIS_IS_THE_ID>/view`).
7. **Create a Google Sheet** for the tracker, share it with the same `client_email` (Editor),
   and copy its ID from the URL
   (`https://docs.google.com/spreadsheets/d/<THIS_IS_THE_ID>/edit`).

> The service account acts like its own Google user. Sharing is what grants it access —
> without step 6 and 7 the API calls will return 404/permission errors.

---

## 4. Slack app setup

1. Go to https://api.slack.com/apps → **Create New App → From scratch**. Pick your workspace.
2. **OAuth & Permissions → Bot Token Scopes**, add:
   `commands`, `chat:write`, `chat:write.public`, `users:read`.
3. **Install to Workspace** (top of that page). Copy the **Bot User OAuth Token**
   (`xoxb-...`) → this is `SLACK_BOT_TOKEN`.
4. **Basic Information → App Credentials** → copy the **Signing Secret** → `SLACK_SIGNING_SECRET`.
5. Leave the app open — you'll add the slash command + interactivity URLs in step 6,
   after ngrok is running.

---

## 5. Configure environment

```bash
cp .env.example .env
```

Fill in `.env`:

```
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-2.0-flash

SLACK_BOT_TOKEN=xoxb-...
SLACK_SIGNING_SECRET=...

GOOGLE_SERVICE_ACCOUNT_FILE=data/service_account.json
DS_DOCX_FILE_ID=<Drive file id of your DS .docx>
TRACKER_SHEET_ID=<Sheet id of your tracker>
TRACKER_SHEET_TAB=Sheet1

MATCH_THRESHOLD=0.75
CHROMA_DIR=data/chroma
CHECKPOINT_DB=data/checkpoints.sqlite
```

---

## 6. Run it locally

Open **two terminals** (venv activated in both).

**Terminal 1 — the app:**
```bash
python -m app.main
```
This starts FastAPI on port 8000. On first start it downloads the DS `.docx` from Drive
and builds the embedding index (takes a few seconds).

**Terminal 2 — ngrok:**
```bash
ngrok http 8000
```
Copy the `https://....ngrok-free.app` URL it prints.

**Back in your Slack app config:**
- **Slash Commands → Create New Command**: Command `/link-ds`,
  Request URL `https://<your-ngrok>.ngrok-free.app/slack/events`.
- **Interactivity & Shortcuts → turn ON**, Request URL
  `https://<your-ngrok>.ngrok-free.app/slack/events`.
- Reinstall the app if Slack prompts you.

Now type `/link-ds` in any channel. A modal opens → fill in the story → submit → watch the
agent respond with candidates or a drafted entry and the Approve/Edit/Reject buttons.

> ngrok's free URL changes every restart. When it changes, update the two Request URLs in
> the Slack app config.

---

## 7. Project layout

```
app/
  main.py                FastAPI + Slack request handler entrypoint
  config.py              Loads .env into a typed Settings object
  graph.py               LangGraph pipeline: nodes, edges, human-gate interrupt
  state.py               The shared state object passed between graph nodes
  agents/
    matcher.py           Semantic search → ranked candidate DS IDs
    drafter.py           Gemini drafts a new DS entry for the right family
    reviewer.py          Gemini reviews the draft's format/style (self-correction)
  integrations/
    llm.py               Google Gemini wrapper
    vectorstore.py       ChromaDB + sentence-transformers index over the DS doc
    ds_document.py       Parse DS .docx into entries; insert a new entry
    drive_client.py      Download latest DS revision / upload updated revision
    sheets_client.py     Append User Story ↔ DS ID rows to the tracker
  slack/
    blocks.py            Block Kit message + modal builders
    handlers.py          Slash command, modal submit, button click handlers
scripts/
  build_index.py         Rebuild the embedding index on demand
  make_sample_ds.py      Generate a sample DS .docx (for local testing without Drive)
data/                    service_account.json, chroma/, checkpoints.sqlite (gitignored)
tests/
  test_ds_document.py    Unit tests for DS parsing + ID generation
```

---

## 8. How the human-in-the-loop actually works

LangGraph runs the pipeline until the `human_gate` node calls `interrupt()`. At that moment
the entire run state is written to `data/checkpoints.sqlite`, keyed by a `thread_id` (we use
the Slack message timestamp). The process is then free — it is not blocked waiting.

When you click Approve/Edit/Reject in Slack, the button click hits `/slack/events`, we look up
that `thread_id`, and resume the exact same run with `graph.invoke(Command(resume=<decision>),
config={"configurable": {"thread_id": ...}})`. The graph picks up right where it left off and
runs the write-back nodes. This is why a restart or crash mid-approval doesn't lose the
proposal — the state lives in SQLite, not in memory.

---

## 9. Upgrade paths (talking points for interviews)

- Swap the Slack story source for **Azure Boards** by adding an `AzureBoardsStorySource`
  behind the same interface — nothing downstream changes.
- Swap **SQLite → Postgres** for the checkpointer to run multiple workers.
- Restrict who may click **Approve** (segregation of duties — maps to GxP controls).
- Add a coverage dashboard over the tracker sheet.
